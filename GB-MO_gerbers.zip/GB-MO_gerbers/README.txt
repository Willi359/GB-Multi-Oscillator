DIRECTORY STRUCTURE:
- files for classic Game Boy (DMG) are in the root directory
- files for Game Boy Pocket (MGB) are in /GBP directory
- [FUTURE] files for Game Boy Color (CGB) are in /GBC directory

LAST MINUTE ADDITIONS:
- the functional pcbs (left & right) for Game Boy Pcket are a bit tall maybe you have to sand them down a little
- a bit of hot glue can help fix the central PCB in place on Game Boy Pocket modules or you skip / modify the headers and solder them togehter
- on Game Boy Pocket extension modules or triple oscillators you have to get creative to fix the floating half of the central PCB. there are two mounting holes that could help

KNOWN PROBLEMS & FEEDBACK:
- pending